---
layout: post
title: Named Set | PivotGrid | ASP.NET | Syncfusion
description: named set
platform: aspnet
control: PivotGrid
documentation: ug
---

#Named Set

I>This feature is applicable only for OLAP datasource at both Client Mode and Server Mode

Named set is a multidimensional expression (MDX) that returns a set of dimension members, which can be created by combining cube data, arithmetic operators, numbers and functions. You can set Named Set option in PivotGrid by setting the `isNamedSets` property to true.

{% highlight html %}

<ej:PivotGrid ID="PivotGrid1" runat="server">
    <DataSource Catalog="Adventure Works DW 2008 SE" Cube="Adventure Works" Data="http://bi.syncfusion.com/olap/msmdpump.dll">
        <Rows>
            <ej:Field FieldName="[Date].[Fiscal]"></ej:Field>
        </Rows>
        <Columns>
            <ej:Field FieldName="[Core Product Group]" isNamedSets="true"></ej:Field>
        </Columns>
        <Values>
            <ej:Field Axis="Column">
                <Measures>
                    <ej:MeasuresItems FieldName="[Measures].[Internet Sales Amount]" />
                </Measures>
            </ej:Field>
        </Values>
    </DataSource>
</ej:PivotGrid>

{% highlight html %}

![](KPI_images/namedset.png)