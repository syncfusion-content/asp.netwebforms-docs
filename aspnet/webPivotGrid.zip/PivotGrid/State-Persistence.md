---
layout: post
title: State persistence | PivotGrid | ASP.NET | Syncfusion
description: state persistence
platform: aspnet
control: PivotGrid
documentation: ug
---


# State persistence

I> This feature is applicable only for Relational datasource.

Expand and collapse state of row and column headers are maintained during every UI interaction.

